using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using StaffingPortalBackend.DTO;
using StaffingPortalBackend.Models;

namespace StaffingPortalBackend.Services
{
    public class SalaryReviewHistoryService : ISalaryReviewHistoryService
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;

        public SalaryReviewHistoryService(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<IEnumerable<SalaryReviewHistoryReadDto>> GetAllHistoryAsync()
        {
            var history = await _context.SalaryReviewHistories.ToListAsync();
            return _mapper.Map<IEnumerable<SalaryReviewHistoryReadDto>>(history);
        }

        public async Task<IEnumerable<SalaryReviewHistoryReadDto>> GetHistoryByPersonIdAsync(int personId)
        {
            var history = await _context.SalaryReviewHistories
                .Where(srh => srh.PersonId == personId)
                .ToListAsync();

            return _mapper.Map<IEnumerable<SalaryReviewHistoryReadDto>>(history);
        }

        public async Task<SalaryReviewHistoryReadDto> GetHistoryByIdAsync(int id)
        {
            var history = await _context.SalaryReviewHistories.FindAsync(id);
            return _mapper.Map<SalaryReviewHistoryReadDto>(history);
        }

        public async Task CreateHistoryAsync(SalaryReviewHistoryCreateDto historyDto)
        {
            if (string.IsNullOrWhiteSpace(historyDto.ReviewResult))
            {
                historyDto.ReviewResult = "Approved"; // значение по умолчанию
            }

            Console.WriteLine($"Creating history with data: " +
                      $"\nReviewResult: {historyDto.ReviewResult}" +
                      $"\nPersonId: {historyDto.PersonId}" +
                      $"\nReviewDate: {historyDto.ReviewDate}" +
                      $"\nJustification: {historyDto.Justification}" +
                      $"\nOldSalary: {historyDto.OldSalary}" +
                      $"\nProposedSalary: {historyDto.ProposedSalary}" +
                      $"\nIsApproved: {historyDto.IsApproved}" +
                      $"\nCurrency: {historyDto.Currency}" +
                      $"\nContractType: {historyDto.ContractType}" +
                      $"\nNewSalaryStartDate: {historyDto.NewSalaryStartDate}" +
                      $"\nSalaryReceivedDate: {historyDto.SalaryReceivedDate}" +
                      $"\nDivisionManagerComments: {historyDto.DivisionManagerComments}" +
                      $"\nTalentManagerComments: {historyDto.TalentManagerComments}");

            var history = _mapper.Map<SalaryReviewHistory>(historyDto);
            _context.SalaryReviewHistories.Add(history);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error saving history: {e.Message}");
                throw;
            }
        }

        public async Task UpdateHistoryAsync(SalaryReviewHistoryUpdateDto historyDto)
        {
            var history = await _context.SalaryReviewHistories.FindAsync(historyDto.HistoryId);
            _mapper.Map(historyDto, history);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteHistoryAsync(int id)
        {
            var history = await _context.SalaryReviewHistories.FindAsync(id);
            _context.SalaryReviewHistories.Remove(history);
            await _context.SaveChangesAsync();
        }

        public async Task ArchiveSalaryReview(int salaryReviewId)
        {
            var salaryReview = await _context.SalaryReviews.FindAsync(salaryReviewId);
            if (salaryReview != null)
            {
                var historyRecord = _mapper.Map<SalaryReviewHistory>(salaryReview);
                _context.SalaryReviewHistories.Add(historyRecord);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> ArchivePreviousSalaryReview(int personId)
        {
            var salaryReviews = await _context.SalaryReviews
                .Where(sr => sr.PersonId == personId)
                .OrderByDescending(sr => sr.ReviewDate)
                .ToListAsync();

            var previousSalaryReview = salaryReviews.LastOrDefault();

            if (previousSalaryReview != null)
            {
                var historyRecord = _mapper.Map<SalaryReviewHistory>(previousSalaryReview);
                _context.SalaryReviewHistories.Add(historyRecord);
                _context.SalaryReviews.Remove(previousSalaryReview);
                await _context.SaveChangesAsync();
                return true;
            }

            return false;
        }
    }
}
