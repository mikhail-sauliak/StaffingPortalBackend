using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using StaffingPortalBackend.DTO;
using StaffingPortalBackend.Services;
using System.Threading.Tasks;

namespace StaffingPortalBackend.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class SalaryReviewHistoryController : ControllerBase
    {
        private readonly ISalaryReviewHistoryService _salaryReviewHistoryService;

        public SalaryReviewHistoryController(ISalaryReviewHistoryService salaryReviewHistoryService)
        {
            _salaryReviewHistoryService = salaryReviewHistoryService;
        }

        // GET: api/SalaryReviewHistory
        [HttpGet]
        public async Task<IActionResult> GetAllHistory()
        {
            var historyDto = await _salaryReviewHistoryService.GetAllHistoryAsync();
            return Ok(historyDto);
        }

        // GET: api/SalaryReviewHistory/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetHistoryByPersonId(int id)
        {
            var historyDto = await _salaryReviewHistoryService.GetHistoryByPersonIdAsync(id);
            if (historyDto == null) return NotFound();
            return Ok(historyDto);
        }

        // POST: api/SalaryReviewHistory
        [HttpPost]
        public async Task<IActionResult> CreateHistory([FromBody] SalaryReviewHistoryCreateDto historyDto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            await _salaryReviewHistoryService.CreateHistoryAsync(historyDto);
            //  CreateHistoryAsync не возвращает объект
            return StatusCode(201);
        }

        // PUT: api/SalaryReviewHistory/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateHistory(int id, [FromBody] SalaryReviewHistoryUpdateDto historyDto)
        {
            if (id != historyDto.HistoryId) return BadRequest("ID mismatch");
            if (!ModelState.IsValid) return BadRequest(ModelState);
            await _salaryReviewHistoryService.UpdateHistoryAsync(historyDto);
            return NoContent();
        }

        // DELETE: api/SalaryReviewHistory/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteHistory(int id)
        {
            await _salaryReviewHistoryService.DeleteHistoryAsync(id);
            return NoContent();
        }
    }
}
